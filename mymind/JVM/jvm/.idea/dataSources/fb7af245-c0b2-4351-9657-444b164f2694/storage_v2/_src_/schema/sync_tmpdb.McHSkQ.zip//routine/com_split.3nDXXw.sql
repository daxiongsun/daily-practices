create function com_split(Varstring varchar(100))
  returns varchar(50)
  BEGIN
    DECLARE len INT DEFAULT 0;
    DECLARE pos INT DEFAULT 1;
    DECLARE Tmp VARCHAR(100) DEFAULT '';
    DECLARE zn VARCHAR(100) DEFAULT '';
    DECLARE en VARCHAR(100) DEFAULT '';
    DECLARE num VARCHAR(100) DEFAULT '';
    SET len=CHAR_LENGTH(Varstring);
    loop_lable:LOOP
      IF pos > len THEN
        LEAVE loop_lable;
      end if;
      IF MID(Varstring,pos,1)REGEXP'[0-9]' THEN
        SET num=CONCAT(num,MID(Varstring,pos,1));
        IF pos < len && NOT MID(Varstring,pos+1,1)REGEXP'[0-9]' OR pos = len THEN
          IF NOT Tmp='' THEN
            SET Tmp=CONCAT(Tmp,',');
          end if;
          SET Tmp=CONCAT(Tmp,num);
          SET num=''; # 置空,备下次使用
        end if;
      ELSEIF (MID(Varstring,pos,1)REGEXP '[a-zA-Z]') THEN
        SET en=CONCAT(en,MID(Varstring,pos,1));
        IF pos<len && NOT (MID(Varstring,pos+1,1)REGEXP '[a-zA-Z]') OR pos = len THEN
          IF NOT Tmp='' THEN
            SET Tmp=CONCAT(Tmp,',');
          end if;
          SET Tmp=CONCAT(Tmp,CONV(HEX(en),16,10));
          SET en=''; # 置空,备下次使用
        end if;
      ELSEIF NOT (MID(Varstring,pos,1)REGEXP '^[u0391-uFFE5]') THEN
        SET zn=CONCAT(zn,MID(Varstring,pos,1));
        IF pos<len && (MID(Varstring,pos+1,1)REGEXP '^[u0391-uFFE5]') OR pos = len THEN
          IF NOT Tmp='' THEN
            SET Tmp=CONCAT(Tmp,',');
          end if;
          SET Tmp=CONCAT(Tmp,CONV(HEX(zn),16,10));
          SET zn=''; # 置空,备下次使用
        end if;
      END IF;
      SET pos = pos+1;
    END LOOP;
    #     RETURN REVERSE(Tmp);
    RETURN Tmp;
  END;

