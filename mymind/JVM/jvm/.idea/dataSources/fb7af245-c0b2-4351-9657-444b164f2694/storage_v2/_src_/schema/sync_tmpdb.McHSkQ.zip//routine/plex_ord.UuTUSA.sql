create function plex_ord(str varchar(255))
  returns varchar(255)
  begin
    declare p_res VARCHAR(255) default '';
    declare p_tmp VARCHAR(255) default '';
#     declare l_i INT(255) default 1;
    declare p_zn VARCHAR(255) default '';
    declare p_en VARCHAR(255) default '';
    declare l_tmp VARCHAR(255) default '';

    set str = SUBSTRING_INDEX(str,'/',-1);
    set p_zn = Num_char_extract(str,3);
    set p_en = Num_char_extract(str,2);

    set p_tmp=substring(str,1,1);
    set l_tmp=right(str, 1);
    set @p_res = '';
    set @l_i = 1;
    loop_lable:loop
      set @p_res = concat(@p_res, concat(concat('hex(', @l_i), ')'));
      set @p_res = concat(@p_res, ',');
#       set @p_res = "concat(@p_res, '打')";
      set @l_i = @l_i+1;
      if @l_i >3 then
        set @p_res = concat(@p_res, concat(concat('hex(', 4), ')'));
        leave loop_lable;
      end if ;
    end loop;
    return @p_res;
  end;

