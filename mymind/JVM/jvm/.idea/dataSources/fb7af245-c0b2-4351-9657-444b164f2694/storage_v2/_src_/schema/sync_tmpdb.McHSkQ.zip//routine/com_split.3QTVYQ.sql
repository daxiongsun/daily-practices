create function com_split(vars varchar(255))
  returns mediumtext
  BEGIN
    DECLARE len INT DEFAULT 0;
    DECLARE pos INT DEFAULT 1;
    DECLARE maxLen INT DEFAULT 14;
    DECLARE Tmp TEXT(65535) DEFAULT '';
    DECLARE other VARCHAR(255) DEFAULT '';
    DECLARE num VARCHAR(255) DEFAULT '';
    SET len=CHAR_LENGTH(vars);
    IF len <= 1 OR NOT vars REGEXP '[0-9]'THEN
      RETURN vars;
    END IF;
    loop_lable:LOOP
      IF pos > len THEN
        LEAVE loop_lable;
      END IF;
      IF MID(vars,pos,1)REGEXP'[0-9]' THEN
        SET num=CONCAT(num,MID(vars,pos,1));
        IF pos < len && NOT MID(vars,pos+1,1)REGEXP'[0-9]' OR pos = len THEN
          IF CHAR_LENGTH(num) <= maxLen THEN
            SET Tmp=CONCAT(Tmp,LPAD(num+0, maxLen, 0));
          ELSE
            SET Tmp=CONCAT(Tmp,num+0);
          END IF;
          SET num=''; # 置空,备下次使用
        END IF;
      ELSE
        SET other=CONCAT(other,MID(vars,pos,1));
        IF pos < len && MID(vars,pos+1,1)REGEXP'[0-9]' OR pos = len THEN
          SET Tmp=CONCAT(Tmp,other);
          SET other=''; # 置空,备下次使用
        END IF;
      END IF;
      SET pos = pos+1;
    END LOOP;
    #RETURN REVERSE(Tmp);
    RETURN Tmp;
  END;

