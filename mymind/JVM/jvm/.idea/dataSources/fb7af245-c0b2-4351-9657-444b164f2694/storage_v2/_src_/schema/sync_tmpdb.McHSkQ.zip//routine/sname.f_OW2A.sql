create function sname(str varchar(255))
  returns varchar(255)
  begin 
declare p_res VARCHAR(16) default ''; 
declare p_tmp VARCHAR(10) default ''; 
set p_tmp=substring(str,0,1);
if length(p_tmp)>1 then
	set p_res=ord(str);
else
	set p_res=substring_index(str,'/',-1);
end if;
return length(str); 
end;

